/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/SQLTemplate.sql to edit this template
 */
/**
 * Author:  diego
 * Created: 12/11/2022
 */
create database if not exists recursosDB;
USE recursosDB;
CREATE TABLE universidad(
id INT NOT NULL AUTO_INCREMENT,
nombre VARCHAR(45) NOT NULL,
ubicacion VARCHAR(45) NOT NULL,
PRIMARY KEY(id)
);
CREATE TABLE tipos_identificacion(
id INT NOT NULL AUTO_INCREMENT,
nombre VARCHAR(45) NOT NULL,
descripcion VARCHAR(245) NOT NULL,
PRIMARY KEY(id)
);
CREATE TABLE funcionarios (
    id INT NOT NULL AUTO_INCREMENT,
    tipo_documento VARCHAR(45) NOT NULL,
    num_identificacion INT NOT NULL,
    nombres VARCHAR(45) NOT NULL,
    apellidos VARCHAR(45) NOT NULL,
    edad INT NOT NULL,
    sexo CHAR(2) NOT NULL,
    direccion VARCHAR(245) NOT NULL,
    telefono VARCHAR(45) NOT NULL,
    fecha_nacimiento DATE,
    fecha_creacion DATETIME DEFAULT NOW(),
    fecha_actualizacion DATETIME DEFAULT NOW(),
    PRIMARY KEY (id),
    tipos_identificacion_id INT NOT NULL,
    UNIQUE (num_identificacion),
    FOREIGN KEY (tipos_identificacion_id)
	REFERENCES tipos_identificacion (id)
);

CREATE TABLE formaciones_academicas(
id INT NOT NULL AUTO_INCREMENT,
nombre_titulo VARCHAR(45) NOT NULL,
fecha_inicio DATETIME DEFAULT NOW(),
fecha_fin DATETIME DEFAULT NOW(),
nivel_educativo VARCHAR(45) NOT NULL,
PRIMARY KEY(id),
funcionarios_id INT NOT NULL,
FOREIGN KEY(funcionarios_id) REFERENCES funcionarios(id),
universidad_id INT NOT NULL,
FOREIGN KEY(universidad_id)REFERENCES universidad(id)
);



CREATE TABLE parentesco(
id INT NOT NULL AUTO_INCREMENT,
relacion VARCHAR(45) NOT NULL,
convive_con_usted BOOLEAN,
PRIMARY KEY(id),
tipos_identificacion_id INT NOT NULL,
FOREIGN KEY(tipos_identificacion_id) REFERENCES tipos_identificacion(id)
);

CREATE TABLE grupo_familiares(
id INT NOT NULL AUTO_INCREMENT,
num_identificacion INT NOT NULL,
nombre VARCHAR(45) NOT NULL,
edad INT NOT NULL,
PRIMARY KEY(id),
parentesco_id INT NOT NULL,
FOREIGN KEY(parentesco_id)REFERENCES parentesco(id),
funcionarios_id INT NOT NULL,
FOREIGN KEY(funcionarios_id)REFERENCES funcionarios(id)
);

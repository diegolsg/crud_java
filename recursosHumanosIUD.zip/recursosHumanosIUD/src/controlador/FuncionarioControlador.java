/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;


 
import dao.FuncionarioDao;
import dao.FuncionarioDaoImpl;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import model.Funcionario;
import dto.FuncionarioDto;


public class FuncionarioControlador {
    
    private final FuncionarioDao funcionarioDao;

    public FuncionarioControlador(FuncionarioDao funcionarioDao) {
        this.funcionarioDao = funcionarioDao;
    }
    
    public DefaultTableModel llenarTabla(){
        DefaultTableModel model = new DefaultTableModel(){
            @Override
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        model.addColumn("Id");
        model.addColumn("Numero Doc.");
        model.addColumn("Nombre");
        model.addColumn("Apellido");
        model.addColumn("Fecha Nac.");
        model.addColumn("edad");
        model.addColumn("direccion");
        model.addColumn("sexo");
        model.addColumn("telefono");
        model.addColumn("tipo de id");
        model.addColumn("Estado civil");
        List<FuncionarioDto> funcionarios = funcionarioDao.findAll();
        String [] registros = new String[11];
        for (FuncionarioDto f: funcionarios){
            registros[0] = String.valueOf(f.getId());
            registros[1] = f.getNumeroIdentificacion();
            registros[2] = f.getNombres();
            registros[3] = f.getApellidos();
            registros[4] = f.getFechaNacimiento().toString();
            registros[5] = String.valueOf(f.getEdad());
            registros[6] = String.valueOf(f.getDireccion());
            registros[7] = String.valueOf(f.getSexo());
            registros[8] = String.valueOf(f.getTelefono());
            registros[9] = f.getDescripcionTipoIdentificacion();
            registros[10]= f.getDescripcionEstadoCivil();
        
           
            model.addRow(registros);
        }
        return model;
    }
    
    public Funcionario listarPorDocumento(String documento){
        return funcionarioDao.findByDocumento(documento);
      
    }
    
    public int sav(Funcionario funcionario){
        return funcionarioDao.guardar(funcionario);
    }
   
    public int edit(Funcionario funcionario){
        System.out.println("editado----");
        return funcionarioDao.editar(funcionario);
        
      }
    public void delete(String documento){
        FuncionarioDao eliminardao = new FuncionarioDaoImpl();
        eliminardao.eliminar(documento);
        System.out.println("documento");
    }
           
}
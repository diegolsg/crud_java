/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;
        
import dao.EstadoCivilDao;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import model.EstadoCivil;


/**
 *
 * @author diego
 */
public class EstadoCivilControlador {
    
    private EstadoCivilDao estadoCivilDao;

    public EstadoCivilControlador(EstadoCivilDao estadoCivilDao) {
        this.estadoCivilDao = estadoCivilDao;
    }
    
    public DefaultComboBoxModel llenarCombo(){
        DefaultComboBoxModel modelo = new DefaultComboBoxModel();
        List<EstadoCivil> estadoCoCr = estadoCivilDao.findAll();
        for(EstadoCivil t:estadoCoCr){
            modelo.addElement(t.getNombre());
        }
        return modelo;
    }
}

    

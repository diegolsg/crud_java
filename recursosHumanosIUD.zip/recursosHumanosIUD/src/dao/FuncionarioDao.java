/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import java.util.List;
import model.Funcionario;
import dto.FuncionarioDto;

/**
 *
 * @author diego
 */
public interface FuncionarioDao {
    List<FuncionarioDto> findAll();
    Funcionario findByDocumento(String documento);
    int guardar(Funcionario funcionario);
    int editar(Funcionario funcionario);
    void eliminar(String documento);
    
}

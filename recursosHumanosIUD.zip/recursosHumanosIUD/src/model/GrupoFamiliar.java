/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author diego
 */
public class GrupoFamiliar {
    private int id;
    private String nombre;
     private String numIdentificacion ;
    private int edad;
    

    public GrupoFamiliar() {
    }

    public GrupoFamiliar(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNum_identificacion() {
        return numIdentificacion;
    }

    public void setNum_identificacion(String num_identificacion) {
        this.numIdentificacion = numIdentificacion;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
   
}

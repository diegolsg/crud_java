/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author diego
 */
public class Parentesco {
    private int id;
    private String realcion ;
    private boolean convivencia;

    public Parentesco() {
    }

    public Parentesco(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRealcion() {
        return realcion;
    }

    public void setRealcion(String realcion) {
        this.realcion = realcion;
    }

    public boolean isConvivencia() {
        return convivencia;
    }

    public void setConvivencia(boolean convivencia) {
        this.convivencia = convivencia;
    }
    
}
